#!/bin/bash
echo "Please ensure you have about 6GB free. Uncomment the lines below to proceed with downloading the dataset" >&2
#source_path="http://gvv.mpi-inf.mpg.de/projects/SingleShotMultiPerson"
#if [ ! -f "./MultiPersonTestSet.zip" ]; then
#  wget "$source_path/MultiPersonTestSet.zip"  
#fi