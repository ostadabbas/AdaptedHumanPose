function out_struct = mpii_3D_error(method_name, error_vector)
       out_struct = struct('method', method_name, 'error', error_vector);
end